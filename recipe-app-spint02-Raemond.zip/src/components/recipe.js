export const Recipe = (name, ingredients, amounts, steps, tags) => { 
    return {
        name: name, 
        ingredients: ingredients, 
        amounts: amounts, 
        steps: steps, 
        tags: tags
    } 
}