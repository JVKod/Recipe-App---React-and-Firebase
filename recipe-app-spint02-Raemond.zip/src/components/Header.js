import React from "react";
import './Header.css';
// import { Link, useNavigate } from "react-router-dom";

function Header() {
    return (
      <div>
        <h1>
          Recipe App
        </h1>
        
      </div>
    );
  }
  
  export default Header;