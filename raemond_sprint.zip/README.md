# Recipe-App-Application-Project

# Product Vision Board

*Open "Group_4_INFO5139-W02-01-The_Product_Vision_Board_31.05.171.pdf" file to view the product vision board

# Product Backlog

*Open "group_4_product_backlog.csv" file to view the user stories

# Sprint Planning Meeting 01

*Open "Group 4 - INFO-5139 - Sprint Planning Meeting 01.xlsx" file to view Sprint Planning Meeting 01

*3 tabs of information to view, Agenda, Current Sprint and Technology
