import './App.css';
import Header from './components/Header';
/* import { auth, db } from './firebaseConfig'; */
import Signup from "./components/Signup"
import SearchBar from './components/SearchBar';
import 'bootstrap/dist/css/bootstrap.min.css';
import {Container} from "react-bootstrap";
import { AuthProvider } from './contexts/AuthContext';
import { BrowserRouter as Router, Routes , Route } from "react-router-dom"
import Login from "./components/Login"
import Dashboard from "./components/Dashboard"
import PrivateRoute from "./components/PrivateRoute"

function App() {
  return (
    <div>
      
      <Container
      className="d-flex align-items-center
      justify-content-center" style={{minHeight: "100vh"}}>
      
      <div className="w-100" style={{maxWidth: '400px'}}>
      <Router>
      <AuthProvider>
        <Routes>
        <Route exact path='/' element={<PrivateRoute/>}>
            <Route exact path='/' element={<Dashboard/>}/>
          </Route>
          <Route path="/signup" element={<Signup/>} ></Route>
          <Route path="/login" element={<Login/>} ></Route>
        </Routes>
      </AuthProvider>
      </Router>
      </div>
     
      </Container>
      
      
      <Header></Header>
      <SearchBar></SearchBar>
    </div>
  );
}

export default App;
