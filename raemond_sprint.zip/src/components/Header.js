import React from "react";
import './Header.css';

function Header() {
    return (
      <div>
        <h1>
          Recipe App
        </h1>
      </div>
    );
  }
  
  export default Header;