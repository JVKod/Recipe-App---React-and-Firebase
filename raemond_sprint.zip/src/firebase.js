import * as firebase from 'firebase/app';
import { getAuth } from 'firebase/auth';

const app = firebase.initializeApp({
    apiKey: "AIzaSyCdvwHtab9ypXytTnTw_2iGHz8X4R7npFg",
    authDomain: "auth-development-c3789.firebaseapp.com",
    projectId: "auth-development-c3789",
    storageBucket: "auth-development-c3789.appspot.com",
    messagingSenderId: "948912140400",
    appId: "1:948912140400:web:789d75e642a38c926784b5"

})

export const auth = getAuth(app)
export default app