const FavouritesDisplay = () => {
    return (
      <div className='favouriteBox'>Favourite Recipes</div>
    );
  }

  export default FavouritesDisplay;